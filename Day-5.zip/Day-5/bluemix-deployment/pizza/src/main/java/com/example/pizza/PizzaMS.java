package com.example.pizza;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("pizza")
@ApplicationScoped
public class PizzaMS {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("menu")
	public List<String> pizzaMenu() {
		System.out.println("INFO ========> Inside PizzaMS.pizzaMenu()");
		List<String> list = Arrays.asList("Country Special","Farm House","Veggie Delight");
		return list;
	}

}